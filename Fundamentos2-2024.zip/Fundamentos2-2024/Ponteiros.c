#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){

// PONTEIROS

    int valor1 = 10, valor2 = 20;
    int *ptr1, *ptr2;

    ptr1 = &valor1;
    ptr2 = &valor2;

    printf("Ponteiro 1: %p == %i\n", ptr1, valor1);
    printf("Ponteiro 2: %p == %i\n", ptr2, valor2);

// PONTEIROS INTEIROS

    int Int = 10;
    int* ptrInteiro;
    ptrInteiro = &Int;

    printf("Ponteiro Inteiro Antes: %p\n", ptrInteiro);
    printf("Ponteiro Inteiro + 1: %p\n", ptrInteiro + 1);

// PONTEIROS GENERICOS 

    void* ptrGenerico;
    ptrGenerico = &ptrGenerico;

    printf("Ponteiro Generico Antes: %p\n", ptrGenerico);
    printf("Ponteiro Generico + 1: %p\n", ptrGenerico + 1);

// PONTEIROS POR VETOR

    return 0;
}
