#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
3) Escreva um procedimento que recebe por parâmetro as 3 notas de um
aluno e uma letra. Se a letra for A, o procedimento calcula a média
aritmética das notas do aluno, se for P, a sua média ponderada (pesos: 5, 3
e 2) e se for S, a soma das notas. O valor calculado também deve ser
retornado e exibido na função main.
*/

    float notas[3];
    char opcao;

float media(float notas[3],char opcao){
    switch (opcao){
    
    case '1':
    float media1 = (notas[0]+notas[1]+notas[2])/3;
    return media1;
    break;

    case '2':
    float media2 = ((notas[0]*5) + (notas[1]*3) + (notas[2]*2))/10;
    return media2;
    break;
    
    case '3':
    float soma = notas[0] + notas[1] + notas[2];
    return soma;
    break;

    default: 
    break;

    }

    return 0;
}

int main(){

    for (int i = 0; i < 3; i++){
    printf("Digite a %d° nota: ", i+1);
    scanf("%f", &notas[i]);
}

    printf("Digite o modo desejado\n 1 - Média Aritmética\n 2 - Média Ponderada\n 3- Soma das notas\n");
    setbuf(stdin, NULL);
    scanf("%c", &opcao);

    float resultado;

    resultado = media(notas, opcao);

    printf("O resultado e: %.2f\n", resultado);


    return 0;
}