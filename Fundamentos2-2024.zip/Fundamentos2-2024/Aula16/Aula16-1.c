#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
1) Faça um algoritmo que implemente uma função que receba 3 números
inteiros e retorne o maior valor;
*/

int calculo(float num1, float num2, float num3) {
    
    if (num1 > num2 && num1 > num3) {
        return num1;
    }

    if (num2 > num3 && num2 > num1) {
        return num2;
    }

    if (num3 > num1 && num3 > num2) {
        return num3;
    }

    return 0;
}

int main() {

    int num[3];

    int maiorvalor = 0;

    for(int i = 0; i < 3; i++){
        printf("Digite o %i número: ", i+1);
        scanf("%i", &num[i]);
    }

    maiorvalor = calculo(num[0], num[1], num[2]);

    printf("O maior numero é: %i\n", maiorvalor);

    return 0;
}