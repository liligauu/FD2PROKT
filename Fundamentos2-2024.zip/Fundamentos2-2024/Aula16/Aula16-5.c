#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
5) Crie uma função que que receba o valor de um inteiro
positivo N, calcule e retorne o fatorial desse número.
*/

int calculo_fatorial(int valor){

    int p = 0, u = 1, a;
    if (valor == 0){
        return 1;
    }else{
        for(int i = 1; i <= valor; i++){
        a = p + u;
        p = u;
        u = a;
    }
    return valor * calculo_fatorial(valor-1);
    }

return 0;
}

int main(){

    int valor;

    printf("Digite um valor para o calculo do fatorial:");
    scanf("%d", &valor);

    int resultado = calculo_fatorial(valor);

    printf("O resultado do fatorial de %d e %d\n", valor, resultado);

    return 0;
}