#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
2) Elabore uma função que receba por parâmetro o sexo (caractere) e a
altura de uma pessoa (real), calcule e retorne seu peso ideal. Para isso,
utilize as fórmulas a seguir.
 Para homens: (72.7 * altura) - 58
 Para mulheres: (62.1 * altura) - 44.7
*/

float calculo(char genero, float altura){

        if (genero == 'm' || genero == 'M'){
        float homem = (72.7 * altura) - 58;
        return homem;
    }
        if (genero == 'f' || genero == 'F'){
        float mulher = (62.1 * altura) - 44.7;
        return mulher;
    }

    return 0;
}


int main(){

    char genero;    
    float altura;
    float resultado;

    printf("Digite o seu genero sendo M para masculino e F para feminino: ");
    scanf("%c", &genero);
    
    printf("Agora, digite a sua altura em metros: ");
    scanf("%f", &altura);

    resultado = calculo(genero, altura);

    printf("Seu peso ideal e: %.2f\n", resultado);

    return 0;
}