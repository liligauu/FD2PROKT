#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
4) Faça uma função que receba a média final de um aluno
por parâmetro e retorne o seu conceito, conforme a tabela
abaixo:
[ 9 - 10] A
[ 7 – 9 [ B
[ 5 - 7 [ C
[ 0 – 5 [ D
*/

float GPA(float nota){

    if (nota >= 9 && nota <= 10)
    {
        nota = 'A';
        return nota;
    }
    else if (nota >= 7 && nota < 9)
    {
        nota = 'B';
        return nota;
    }
    else if (nota >= 5 && nota < 7)
    {
        nota = 'C';
        return nota;
    }
    else if (nota >= 0 && nota < 5)
    {
        nota = 'D';
        return nota;
    }

    return 0;
}

int main()
{
    float nota;

    printf("Digite a sua nota:");
    scanf("%f", &nota);

    char resultado = GPA(nota);

    printf("GPA: %c\n", resultado);

    return 0;
}