#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/*
1) Crie uma estrutura para representar as coordenadas de
um ponto no plano (posições X e Y). Em seguida, declare
e leia do teclado dois pontos e exiba a distância entre
eles. 
*/

typedef struct{
    float x;
    float y;
} Coordinates;

int main(){

    float distancia;
    Coordinates ponto1;
    Coordinates ponto2;

    printf("Digite o X¹:");
    scanf("%f", &ponto1.x);
    printf("Digite o Y¹:");
    scanf("%f", &ponto1.y);

    printf("Digite o X²:");
    scanf("%f", &ponto2.x);
    printf("Digite o Y²:");
    scanf("%f", &ponto2.y);

    distancia = sqrt(pow(ponto2.x-ponto1.x,2)+
                     pow(ponto2.y-ponto1.y,2));

    printf("A distancia é %.2f\n", distancia);

    return 0;
}

// gcc AULA14-1.c -o Teste -lm