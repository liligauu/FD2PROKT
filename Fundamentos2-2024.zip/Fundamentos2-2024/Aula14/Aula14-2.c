#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/*
2) Escreva um trecho de código para fazer a criação dos
novos tipos de dados conforme solicitado abaixo:
 Horário: composto de hora, minutos e segundos.
 Data: composto de dia, mês e ano.
 Compromisso: local, horário e texto que descreve o
compromisso.
*/

    typedef struct{
        int Hora;
        int Minutos;
        int Segundos;
    } Horario;

    typedef struct{
        int Dia;
        int Mes;
        int Ano;
    } Data;

    typedef struct{
        char Local[101];
        char Texto[101];
        Data data; 
        Horario horario;
    } Compromisso;

int main(){

    Compromisso meu_compromisso;

    printf("Digite o Local:");
    fgets(meu_compromisso.Local, 101, stdin);
    meu_compromisso.Local[strcspn(meu_compromisso.Local, "\n")] = '\0';
    setbuf(stdin, NULL);

    printf("Digite a descrição:");
    fgets(meu_compromisso.Texto, 101, stdin);
    meu_compromisso.Texto[strcspn(meu_compromisso.Texto, "\n")] = '\0';
    setbuf(stdin, NULL);

// DATA

    printf("Digite o dia:");
    scanf("%d", &meu_compromisso.data.Dia);
    do{
        printf("Digite o dia:");
        scanf("%d", &meu_compromisso.data.Dia);
    }while(meu_compromisso.data.Dia > 31 || meu_compromisso.data.Dia < 0);

    printf("Digite o mês:");
    scanf("%d", &meu_compromisso.data.Mes);
    do{
        printf("Digite o mês:");
        scanf("%d", &meu_compromisso.data.Mes);
    }while(meu_compromisso.data.Mes > 12 || meu_compromisso.data.Mes < 0);

    printf("Digite o ano:");
    scanf("%d", &meu_compromisso.data.Ano);

// HORARIO

    printf("Digite a hora:");
    scanf("%d", &meu_compromisso.horario.Hora);
    do{
        printf("Digite a hora:");
        scanf("%d", &meu_compromisso.horario.Hora);
    }while(meu_compromisso.horario.Hora > 24 || meu_compromisso.horario.Hora < 0);

    printf("Digite o minuto:");
    scanf("%d", &meu_compromisso.horario.Minutos);
    do{
        printf("Digite o minuto:");
        scanf("%d", &meu_compromisso.horario.Minutos);
    }while(meu_compromisso.horario.Minutos > 60 || meu_compromisso.horario.Minutos < 0);

    printf("Digite os segundos:");
    scanf("%d", &meu_compromisso.horario.Segundos);
    do{
        printf("Digite os segundos:");
        scanf("%d", &meu_compromisso.horario.Segundos);
    }while(meu_compromisso.horario.Segundos > 60 || meu_compromisso.horario.Segundos < 0);

// SHOW ARGS

    system("clear");
    printf("Compromisso Salvo!\n");
    printf("Local: %s\n", meu_compromisso.Local);
    printf("Data: %02d/%02d/%d\n", meu_compromisso.data.Dia, meu_compromisso.data.Mes, meu_compromisso.data.Ano);
    printf("Horário: %02d:%02d;%02d\n", meu_compromisso.horario.Hora, meu_compromisso.horario.Minutos, meu_compromisso.horario.Segundos);
    printf("Descrição: %s\n", meu_compromisso.Texto);

    return 0;
}