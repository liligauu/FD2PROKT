#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

/*
Na tarde de ontem, 06 de dezembro, alguns pokemon da Amazon (AWS) pararam de funcionar. 
Com isso, diversos serviços ficaram indisponíveis. Dentre eles, os pokemon da Riot responsáveis pelos jogos League of Legends, 
Valorant e Wild Rift.
Você foi convocado em uma missão de emergência para ajudar 
a identificar os locais das falhas e gerar os relatórios para os técnicos responsáveis por reestabelecer os serviços.

Para isso, a central da Amazon está recebendo as notificações de falhas ao redor do mundo. Você devera implementar um sistema para salvar e processar essas notificações. Para isso:

a) (5 pontos) Aloque dinamicamente um vetor de Notificações de tamanho 5. Cada Notificação é uma estrutura que contém:
* nome (string tam: 20):
* Cidade(string tam: 20):
* Quantidade de pokemon UP - ativos (inteiro)
* Quantidade de pokemon Down - com problemas (inteiro)

Os países possíveis são: Brasil, EUA, França, Inglaterra, China e Japão

b) (10 pontos) Receba os dados de diversas notificações de falhas e vá armazenando neste vetor de Notificações. A cada vez que o tamanho do vetor se tornar insuficiente, realoque seu tamanho aumentando o vetor em 5 unidades.
Ao receber o valor "fim" como entrada de um nome, o sistema de entradas deverá parar e o vetor tamanho do vetor ajustado ao tamanho exato da quantidade de relatórios.

c) (5 pontos) Salve os dados em um aquivo BINÁRIO chamado "notifications.dat". Feche o arquivo e libere a memória utilizada pelo vetor;

d) (5 pontos) Abra o arquivo gerado anteriormente, carregue os dados em um vetor de Relatórios alocado dinamicamente.

e) (5 pontos) Calcule o total de pokemon ativos e com problemas em cada país. Exiba os dados na tela e gere um arquivo MODO TEXTO chamado "report.txt" no seguinte formato:
nome       |  UP |DOWN |  RATE|
Brasil     |   80|   30|   25%|
EUA        |  200|   50|   20%|
França     |   80|    5|    6%|
Inglaterra |  100|   12|   11%|
China      |  117|    3|    3%|
Japão      |   45|    5|   10%| 


Obs: Caso você tenha problemas com a alocação dinâmica, faça um vetor estático de tamanho 10 e prossiga nos códigos, você perderá os pontos dessa parte mas prosseguirá normalmente com a nota da parte de arquivos.

Dados de exemplo:


nome       |CIDADE      |UP  |DOWN |
EUA        |New York    | 100|   30|
Brasil     |Sao Paulo   |  50|   20|
Inglaterra |Londres     |  70|    8|
Brasil     |Brasilia    |  20|    5|
Brasil     |Fortaleza   |  10|    5|
Japão      |Tokyo       |  45|    5|
EUA        |Boston      |  25|    5|
EUA        |Los Angeles |  50|   10|
França     |Paris       |  50|    4|
China      |Pequim      | 117|    3|
França     |Nice        |  30|    1|
Londres    |Manchester  |  30|    4|
EUA        |Orlando     |  25|    5|
*/

/*
a) (5 pontos) Aloque dinamicamente um vetor de Notificações de tamanho 5. Cada Notificação é uma estrutura que contém:
* nome (string tam: 20):
* Cidade(string tam: 20):
* Quantidade de pokemon UP - ativos (inteiro)
* Quantidade de pokemon Down - com problemas (inteiro)

Os países possíveis são: Brasil, EUA, França, Inglaterra, China e Japão
*/

typedef struct
{
    char nome[20];
    int numero;
    int ataque;
    int defesa;
} Pokedex;

void LeString(char string[], int tamanho){
    fgets(string, tamanho, stdin);
    string[strcspn(string, "\n")] = '\0';
    setbuf(stdin, NULL);
}

int main(){
    
    /*
    b) (10 pontos) Receba os dados de diversas notificações de falhas e vá armazenando neste vetor de Notificações. 
    A cada vez que o tamanho do vetor se tornar insuficiente, realoque seu tamanho aumentando o vetor em 5 unidades.
    Ao receber o valor "fim" como entrada de um nome, o sistema de entradas deverá parar e o vetor tamanho do vetor 
    ajustado ao tamanho exato da quantidade de relatórios.
    */

    int tamanho = 5;
    int i = 0;
    Pokedex* pokemon = (Pokedex*) malloc (tamanho * (sizeof(Pokedex)));
    if(pokemon == NULL){
        perror("Erro ao alocar memória!\n");
        exit(1);
    }
    
    do{
        printf("Digite o nome do Pokemon('fim' para finalizar): ");
        LeString(pokemon[i].nome, 20);
        if((i == 0) && (strcmp(pokemon[i].nome, "fim") == 0)){
            printf("Você não cadastrou nenhum nome!\n");
            printf("Encerrando o programa!\n");
            free(pokemon);
            return 0;
        }
        if((strcmp(pokemon[i].nome, "fim") == 0) && (i > 0)){
            printf("Fim do cadastro!\n");
            pokemon = (Pokedex*) realloc (pokemon, i * sizeof(Pokedex));
            if(pokemon == NULL){
                perror("Erro ao alocar memória !\n");
                exit(1);
            }
            printf("Tamanho do vetor realocado para %i!\n", i);
            break;
        }
        printf("Digite o numero do %s: ", pokemon[i].nome);
        scanf("%i", &pokemon[i].numero);
        printf("Digite o ataque do pokemon: ");
        scanf("%i", &pokemon[i].ataque);
        printf("Digite a defesa do pokemon: ");
        scanf("%i", &pokemon[i].defesa);
        setbuf(stdin, NULL);
        i++;
        if(i % 3 == 0){
            tamanho += 3;
            pokemon = (Pokedex*) realloc (pokemon, tamanho * sizeof(Pokedex));
            printf("Vetor alocado para %i\n", tamanho);
            if(pokemon == NULL){
                perror("Erro ao alocar memória !\n");
                exit(1);
            }    
        }
    }while(1);

    /*
    c) (5 pontos) Salve os dados em um aquivo BINÁRIO chamado "notifications.dat". 
    Feche o arquivo e libere a memória utilizada pelo vetor;
    */

    FILE* arquivo1 = fopen("notificacoes.dat", "wb");
    if(arquivo1 == NULL){
        perror("Erro ao criar arquivo!\n");
        exit(1);
    }

    fwrite(pokemon, sizeof(Pokedex), i, arquivo1);
    fclose(arquivo1);
    free(pokemon);

    /*
    d) (5 pontos) Abra o arquivo gerado anteriormente, carregue os dados em um vetor de Relatórios alocado dinamicamente.
    */

    FILE* arquivo2 = fopen("notificacoes.dat", "rb");
    if(arquivo2 == NULL){
        perror("Erro ao abrir arquivo!\n");
        exit(1);
    }
    
    Pokedex* relatorios = (Pokedex*) malloc (i * sizeof(Pokedex));
    if(relatorios == NULL){
        perror("Erro ao ler arquivo binário!\n");
        exit(1);
    }

    fread(relatorios, sizeof(Pokedex), i, arquivo2);
    fclose(arquivo2);

    /*
    e) (5 pontos) Calcule o total de pokemon ativos e com problemas em cada país. 
    Exiba os dados na tela e gere um arquivo MODO TEXTO chamado "report.txt" no seguinte formato:
    nome       |  UP |DOWN |  RATE|
    Brasil     |   80|   30|   25%|
    EUA        |  200|   50|   20%|
    França     |   80|    5|    6%|
    Inglaterra |  100|   12|   11%|
    China      |  117|    3|    3%|
    Japão      |   45|    5|   10%| 
    */

    FILE* arquivo3 = fopen("pokedex.csv", "w");
    if(arquivo3 == NULL){
        perror("Erro ao abrir arquivo!\n");
        exit(1);
    }

    fprintf(arquivo3, "%-4s | %-19s | %-4s | %-4s\n", "Numero", "Nome", "Ataque", "Defesa");
    for(int j = 0; j < i; j++){
        fprintf(arquivo3, "%i, %s, %i, %i\n", relatorios[j].numero, relatorios[j].nome, relatorios[j].ataque, relatorios[j].defesa);
    }

    free(relatorios);
    fclose(arquivo3);
    return 0;
}