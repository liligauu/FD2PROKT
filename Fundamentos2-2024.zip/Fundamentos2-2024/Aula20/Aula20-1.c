#include <stdlib.h>
#include <stdio.h>  
#include <string.h>

/*
1) Elabore um programa que leia do usuário o tamanho de um vetor a ser lido. Em
seguida, faça a alocação dinâmica desse vetor. Por fim, leia o vetor do usuário e o
imprima
*/

int main(){

    int *tamanho;

    printf("Digite o tamanho do vetor: ");
    scanf("%i", &tamanho);

    tamanho = (int*) malloc(50 * sizeof(int));
    
    printf("Espaço alocado: %i", tamanho);


    return 0;
}