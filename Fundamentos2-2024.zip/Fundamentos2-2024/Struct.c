#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    char nome[50];
    int idade;
    float peso;
    float altura;
} Aluno;   // ALUNO

int main(){

    Aluno meuAluno;
    strcpy(meuAluno.nome, "José Da Silva");
    meuAluno.idade = 18;
    meuAluno.altura = 1.78;
    meuAluno.peso = 80;

    printf("Nome: %s, idade: %d, peso: %.2f, altura %.2f\n",
    meuAluno.nome,
    meuAluno.idade,
    meuAluno.peso,
    meuAluno.altura);

    Aluno alunos[40];

    for(int i = 0; i < 49; i++)
    {
        setbuf(stdin, NULL);
        printf("Nome:");
        scanf("%19[^\n]", alunos[i].nome);

        printf("Idade:");
        scanf("%d", &alunos[i].idade);

        printf("Peso:");
        scanf("%f", &alunos[i].peso);

        printf("Altura:");
        scanf("%f", &alunos[i].altura);
    }


    return 0;
}